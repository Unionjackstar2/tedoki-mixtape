# TEDOKI Mixtape

Retro-Radiokassettendeck für Android: Internetradio (Radio Browser), UKW-Skala mit
Sendern nach BNetzA-Daten, Mixtape-Aufnahmen und ein virtuelles Kassettenregal.

Ohne Google-Dienste: kein Firebase, keine Play-Services, keine Cloud-Sicherung.
Standort (optional, nur auf Knopfdruck) über den Android-Ortungsdienst.

## Build

GitHub Actions baut bei jedem Push auf `main` eine signierte APK
(Reiter **Actions** → letzter Lauf → **Artifacts**).

Secrets (Settings → Secrets and variables → Actions):

| Secret | Pflicht | Inhalt |
|---|---|---|
| `KEYSTORE_BASE64` | ja* | Keystore als Base64 |
| `KEYSTORE_PASSWORD` | ja* | Keystore-Passwort |
| `KEY_ALIAS` | nein | Alias – wird sonst automatisch ermittelt |
| `KEY_PASSWORD` | nein | Schlüssel-Passwort – sonst = Keystore-Passwort |

\* Ohne Schlüssel wird mit dem Debug-Schlüssel signiert (zum Testen ok, aber keine Updates zwischen Builds möglich).
